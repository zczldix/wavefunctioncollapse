﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// This behaviour marks prototypes on which trees can grow
public class TreeGrowingPrototype : MonoBehaviour { }
